### Atención 

Faltan 2 csv: el correspondiente al gráfico de dispersión y el del consumo de alcohol del segundo trabajo con Datawrapper. Espero que las capturas realizadas en el README.md explicativo del proceso que realicé en Openrefine y los otros 5 archivos csv sean prueba suficiente de que sé utilizar el programa Openrefine y que no he hecho uso de otras herramientas.

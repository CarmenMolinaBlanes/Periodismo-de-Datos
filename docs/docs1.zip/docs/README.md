# Mi Proyecto

Este proyecto es un compilatorio de infografías que usa una barra de navegaciónn para poder buscar entre los distintos análisis gráficos de forma ágil. Surgió de un trabajo académico para la asignatura de Periodismo de Datos en la Universidad UC3M. Su autora es Carmen Molina Blanes.

Licencia del proyecto: Creative Commons BY SA (al ser un trabajo académico he optado por la opción de Creative Commons para que se pueda compartir y adaptar el contenido de mi proyecto libremente. Otra opción que barajé fue la licencia GNU GPL v2)

Está alojado en la url: https://carmenmolinablanes.github.io/Periodismo-de-Datos/
